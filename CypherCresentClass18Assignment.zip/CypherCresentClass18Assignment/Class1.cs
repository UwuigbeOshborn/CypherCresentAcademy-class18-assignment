﻿
using CypherCresentClass18a;


public class Teacher : IModelBase
{
    // Constructors
    public Teacher()
    {

    }
    public Teacher(string name)
    {
        Name = name;
    }
    public Teacher(string employeeId, string name, List<Course> assignedCourse)
    {
        EmployeeId = employeeId;
        Name = name;
        AssignedCourse = assignedCourse;
    }

    // Properties
    public string EmployeeId { get; set; }
    public string Name { get; set; }
    public List<Course> AssignedCourse { get; set; }
}

public class Student : IModelBase
{
    // Constructors
    public Student()
    {

    }
    public Student(string name)
    {
        Name = name;
    }
    public Student(string matN0, string name, List<Course> courseOffered)
    {
        MatN0 = matN0;
        Name = name;
        CourseOffered = courseOffered;
    }
    // Properties
    public string MatN0 { get; set; }
    public string Name { get; set; }
    public List<Course> CourseOffered { get; set; }
}
public class Course : IModelBase
{
    // Constructors
    public Course()
    {

    }
    public Course(string name)
    {
        Name = name;
    }
    // Properties
    public string CourseCode { get; set; }
    public string Name { get; set; }
    public double duration { get; set; }
}
public class Exam : IModelBase
{
    // Constructors

    // Properties
    public Course Course { get; set; }
    public int Score { get; set; }
}
public class Guidance : IModelBase
{
    // Constructors
    public Guidance()
    {
            
    }
    public Guidance( string firstName, string surName, string addres, string phoneNo, string email)
    {
        FirstName = firstName;
        SurName = surName;
        Address = addres;
        PhoneNo = phoneNo;
        Email = email;
    }
    public Guidance(Enums guidanceType, string firstName, string surName, string addres, string phoneNo, string email)
    {
        GuidanceType = guidanceType;
        FirstName = firstName;
        SurName = surName;
        Address = addres;
        PhoneNo = phoneNo;
        Email = email;
    }
    // Properties
    public Enums GuidanceType { get; set; }
    public string FirstName { get; set; }
    public string SurName { get; set; }
    public string Address { get; set; }
    public string PhoneNo { get; set; }
    public string Email { get; set; }
}
public interface IModelBase { }

