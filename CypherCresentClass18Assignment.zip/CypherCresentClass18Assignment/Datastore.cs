﻿public class Datastore<T> where T : IModelBase
{
    // Constructors
    public Datastore()
    {
        this.head = null;
        this.tail = null;
        this.count = 0;
    }

    // Properties / Fields
    private ListNode head;
    private ListNode tail;
    private int count;

    public int Count
    {
        get
        {
            return this.count;
        }
    }

    // Nested Classes
    private class ListNode
    {
        public T Element { get; set; }
        public ListNode NextNode { get; set; }
        public ListNode(T element)
        {
            this.Element = element;
            NextNode = null;
        }
        public ListNode(T element, ListNode prevNode)
        {
            this.Element = element;
            prevNode.NextNode = this;
        }
    }

    // Methods
    // Creates Items
    public void Create(T item)
    {
        if (this.head == null)
        {
            // We have an empty list -> create a new head and tail
            this.head = new ListNode(item);
            this.tail = this.head;
        }
        else
        {
            // We have a non-empty list -> append the item after tail
            ListNode newNode = new ListNode(item, this.tail);
            this.tail = newNode;
        }
        this.count++;
        Console.WriteLine("Item Created Successfully");
    }

    // Reads Items
    public string Read()
    {
        Console.WriteLine("Items Read Successfully");
        return default;
    }
    public void Update(T parameter)
    {
        Console.WriteLine("Updated Successfully");
    }

    //Delete Items
    public int Delete(T item)
    {
        // Find the element containing the searched item
        int currentIndex = 0;
        ListNode currentNode = this.head;
        ListNode prevNode = null;
        while (currentNode != null)
        {
            if (object.Equals(currentNode.Element, item))
            {
                break;
            }
            prevNode = currentNode;
            currentNode = currentNode.NextNode;
            currentIndex++;
        }
        if (currentNode != null)
        {
            RemoveListNode(currentNode, prevNode);
            Console.WriteLine("Updated Successfully");
            return currentIndex;
        }
        else
        {
            // The element is not found in the list -> return -1
            return -1;
        }

    }
    private void RemoveListNode(ListNode node, ListNode prevNode)
    {
        count--;
        if (count == 0)
        {
            // The list becomes empty -> remove head and tail
            this.head = null;
            this.tail = null;
        }
        else if (prevNode == null)
        {
            // The head node was removed --> update the head
            this.head = node.NextNode;
        }
        else
        {
            // Redirect the pointers to skip the removed node
            prevNode.NextNode = node.NextNode;
        }
        // Fix the tail in case it was removed
        if (object.ReferenceEquals(this.tail, node))
        {
            this.tail = prevNode;
        }
    }

    public int IndexOf(T item)
    {
        int index = 0;
        ListNode currentNode = this.head;
        while (currentNode != null)
        {
            if (object.Equals(currentNode.Element, item))
            {
                return index;
            }
            currentNode = currentNode.NextNode;
            index++;
        }
        return -1;
    }

    public bool Contains(T item)
    {
        int index = IndexOf(item);
        bool found = (index != -1);
        return found;
    }
    public void Search(T item)
    {
        Console.WriteLine("Item Searched Successfully");
    }

    public void ResetDataBase(T parameter)
    {
        Console.WriteLine("DataBase Reset Successfully");
    }
}
