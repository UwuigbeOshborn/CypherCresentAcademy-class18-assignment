﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CypherCresentClass18a
{
    public class Enums
    {
        enum GuidanceType
        {
            Father,
            Mother,
            Brother,
            Sister,
            Uncle,
            Aunty,
            Others
        }
    }
}
