﻿// See https://aka.ms/new-console-template for more information
public class MyArrayCounter<T>
{
    // Methods
    public T GetLastItem(params T[] inputArray)
    {
        T lastItem = inputArray[inputArray.Length - 1];

        //Console.WriteLine(String.Join(",", lastItem));
        return lastItem;
    }
    public int TotalCount(params T[] inputArray)
    {
        int count = inputArray.Length;
        //Console.WriteLine(count);
        return count;
    }

    // Properties
}