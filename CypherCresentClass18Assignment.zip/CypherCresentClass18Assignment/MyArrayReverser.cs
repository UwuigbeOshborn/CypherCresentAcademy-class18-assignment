﻿// See https://aka.ms/new-console-template for more information
public class MyArrayReverser<T>
{
    // Methods
    public void ReverseArray(params T[] inputArray)
    {
        //inputArray.Reverse();
        T[] newArray = new T[inputArray.Length];

        for (int i = 0; i < inputArray.Length; i++)
        {
            newArray[i] = inputArray[inputArray.Length - i - 1];
        }
        Console.WriteLine(String.Join(",", newArray));
    }

    // Properties

}