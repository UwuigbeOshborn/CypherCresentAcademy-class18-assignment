﻿// See https://aka.ms/new-console-template for more information
using System.Linq;

Console.WriteLine("---------------     Question 1   -----------------");

MyArrayReverser<int> exampleArray1 = new MyArrayReverser<int>();
exampleArray1.ReverseArray(1, 2, 3, 4, 5, 6, 7, 8);


Console.WriteLine("---------------     Question 2   -----------------");

MyArrayCounter<string> exampleArray2 = new MyArrayCounter<string>();
exampleArray2.GetLastItem("John", "kate", "joy", "James");
Console.WriteLine(exampleArray2.GetLastItem("John", "kate", "joy", "James"));
exampleArray2.TotalCount("John", "kate", "joy", "James");
Console.WriteLine(exampleArray2.TotalCount("John", "kate", "joy", "James"));


Console.WriteLine("---------------     Question 3   -----------------");

var courseList = new List<Course>();
courseList.Add(new Course("MTH"));
courseList.Add(new Course("GNS"));
var myTeacher = new Teacher("ID001", "Mr. Kelvin", courseList);
var teacher_store = new Datastore<Teacher>();
teacher_store.Create(myTeacher);



var courseList2 = new List<Course>();
courseList2.Add(new Course("MTH"));
courseList2.Add(new Course("GNS"));
courseList2.Add(new Course("MEC"));
courseList2.Add(new Course("EEC"));
courseList2.Add(new Course("PET"));
var myStudent = new Student("M.20/1222111/2022", "Osas", courseList2);
var student_store = new Datastore<Student>();
student_store.Create(myStudent);

var myGuidance = new Guidance("Paul", "Oku", "No. 10 Amadin street", "+234 810 597 2646", "paul@gmail.com");
var guidance_store = new Datastore<Guidance>();
guidance_store.Create(myGuidance);

string myStringCourse = "";
var mylist = new List<string>();
foreach (var item in courseList)
{
    mylist.Add(item.Name);
}
myStringCourse = string.Join(',', mylist);

string myStringCourse2 = "";
var mylist2 = new List<string>();
foreach (var item in courseList2)
{
    mylist2.Add(item.Name);
}
myStringCourse2 = string.Join(',', mylist2);

for (int i = 0; i < teacher_store.Count; i++)
{
    Console.WriteLine($"S/N {i + 1}: Teacher Name = {myTeacher.Name}, Teacher ID = {myTeacher.EmployeeId}, AssignedCourses = {myStringCourse}");
}
for (int i = 0; i < student_store.Count; i++)
{
    Console.WriteLine($"S/N {i + 1}: Student Name = {myStudent.Name}, Student Mat No. = {myStudent.MatN0}, CoursesOffered = {myStringCourse2}");
}

var returnType = teacher_store.Read();
var returnType1 = student_store.Read();
var returnType2 = guidance_store.Read();